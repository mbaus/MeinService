#!/bin/sh
java -cp TCPMonPlus.jar com.yasmoicoco.proxy.tcpmon.TCPMonitorPlus
